/*
 ============================================================================
 Name		: WidgetInstaller.h
 Author	  : Nokia
 Copyright   : 
 Description : Exe header file
 ============================================================================
 */

#ifndef __WIDGETINSTALLER_H__
#define __WIDGETINSTALLER_H__

//  Include Files

#include <e32base.h>

//  Function Prototypes

GLDEF_C TInt E32Main();

#endif  // __WIDGETINSTALLER_H__

