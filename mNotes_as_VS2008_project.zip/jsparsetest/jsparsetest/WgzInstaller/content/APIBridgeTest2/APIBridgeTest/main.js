

var originalSendRequest = APIBridge.Internal._sendRequest;

APIBridge.Internal._sendRequest = function(path, parameters, onSuccess, onError) {
	var cb = document.getElementById("wrap_response");
	var processorFunc = onSuccess;
	if (cb.checked) {
		path += (path.indexOf("?") == -1) ? "?" : "&";
		path += "apibridgewrapresponse=true";
		
		processorFunc = function(res){
			var text = document.createTextNode(res.responseText);
			var output = document.getElementById("output");
			output.innerHTML = "";
			output.appendChild(text);
		};
	} 
	
	originalSendRequest(path, parameters, processorFunc, onError);
}


function init() {
	// Disable cursor mode navigation
	//widget.setNavigationEnabled( false );
}

function onStartButtonClicked() {
	widget.openApplication( 0x20023710, "" );
}

function onStopButtonClicked() {
	APIBridge.Internal._sendRequest( "/stop", null,  function() {}, function() {} );		
}

function onClearTokenButtonClicked(){
	APIBridge.Internal._sessionId = "";
	widget.setPreferenceForKey("", APIBridge.Internal.TOKEN_KEY);
}

function hasError(result){
	if (result.ErrorCode !== 0) {
		var output = document.getElementById("output");
		output.innerHTML = "ERROR - code: " + result.ErrorCode;
		if (result.ErrorMessage)
			output.innerHTML += "; ErrorMessage: " + result.ErrorMessage;
			
		return true;
	}
	
	return false;
}

function displayResults(transId, eventCode, result) {
	if (hasError(result))
		return;
	
	var item;
	var out = "";
	
	var iterableList = result.ReturnValue;
	if (!iterableList.getNext)
		iterableList = new APIBridge.IterableList([iterableList]);
	
	while ( item = iterableList.getNext() ) {
		for (var n in item) {
			out += n + "=" + item[n] + "<br />";
		}
		
		out += "<br />";
	}

	var output = document.getElementById("output");
	output.innerHTML = ( out.length > 0 ) ? out : "(Empty list)";
}

function clearOutput() {
	var output = document.getElementById("output");
	output.style.color = "white";
	output.innerHTML = "";
}

function onCallLogClicked() {
	clearOutput();
	
	var ls = APIBridge.getLoggingService();
	ls.GetList(null, displayResults);
}

function onLocationClicked() {
	clearOutput();

	var ls = APIBridge.getLocationService();
	ls.GetLocation(null, displayResults);
}

function onShowImageClicked() {
	clearOutput();

	var src = getSelectedImageSrc();
	if (!src)
		return;

	document.getElementById("output").innerHTML = "<img src='" + src + "' />";
}

function onImagesRefreshClicked() {
	clearOutput();
	
	var mms = APIBridge.getMediaManagementService();
	
	var criteria = {
        sort: {
            key: "FileDate",
            order: "Descending"
        },
		Type: "FileInfo",
		Filter: {
			FileType: "Image"
		}
	};

	
	mms.GetList(criteria, 
		function(transId, eventCode, result) {
			if (hasError(result))
				return;
				
			displayResults(transId, eventCode, result);
			
			var select = document.getElementById("images");
			while (select.firstChild)
				select.removeChild(select.firstChild);

			result.ReturnValue.reset();
			while ( item = result.ReturnValue.getNext() ) {
				var option = document.createElement("option");
				option.value = item.FileNameAndPath;
				option.innerHTML = item.FileNameAndPath;
				select.appendChild(option);
			}	
		}
	);
}

function getSelectedImageSrc() {
	var output = document.getElementById("output");
	var src = document.getElementById("images").value;
	if (!src || !src.length) {
		output.innerHTML = "No image selected.";
		return null;
	}
	
	return src;
}

function onThumbnailClicked() {
	clearOutput();

	var src = getSelectedImageSrc();
	if (!src)
		return;
		
	var output = document.getElementById("output");
	APIBridge.getThumbnail(src,
		function(src) {
			output.innerHTML = "<img src='" + src + "' />";
		},
		function(err) {
			output.innerHTML = err;
		}
	);
}

function onResizeClicked() {
	clearOutput();

	var src = getSelectedImageSrc();
	if (!src)
		return;

	var width = document.getElementById("imagewidth").value;	
	var height = document.getElementById("imageheight").value;
	var mar = document.getElementById("image_mar").checked;	
	var output = document.getElementById("output");
	APIBridge.resizeImg(src, width, height, mar,
		function(src) {
			output.innerHTML = "<img src='" + src + "' />";
		},
		function(err) {
			output.innerHTML = err;
		}
	);
}

function onTakephotoClicked() {
	clearOutput();
	
	var type = document.getElementById("newfileservicetype");
	var output = document.getElementById("output");

	APIBridge.newFileService(
		type.value,
		function(src) {
			document.getElementById("uploadfilename").value = src;

			if (type.value === "Image") {
				if (src && src.length)
					output.innerHTML = "<img src='" + src + "' />";
				else
					output.innerHTML = "No image taken...";				
			}
			else
				output.innerHTML = src;				
		},
		function(res) {
			output.innerHTML = res.status + ";" + res.statusText;
		}
	);	
}

function onFileUploadClicked() {
	clearOutput();

	var file = document.getElementById("uploadfilename").value;	
	var url = document.getElementById("uploadfileserverurl").value;
	var output = document.getElementById("output");

	APIBridge.fileUpload(
		"",
		file,
		url,
		null,
		function(res) {
			output.innerHTML = "RESPONSE: " + res.status + ";" + res.statusText + ";" + res.responseText;
		},
		function(res) {
			output.innerHTML = "ERROR: " + res.status + ";" + res.statusText;
		}
	);	
}

function onSendDTMFClicked()
{
	var dtmfStr = document.getElementById('dtmf').value;
	
	Telephony.sendDTMF(dtmfStr,
		function(text)
		{
			alert(text);
		},
		function (err)
		{
			alert(err.status);
		}
	);
}
